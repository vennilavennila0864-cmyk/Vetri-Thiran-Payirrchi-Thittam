from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.documents import router as documents_router
from app.api.templates import router as templates_router

app = FastAPI(
    title="LegalEase API",
    version="1.0.0",
    description="AI-powered legal document generator"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(documents_router, prefix="/api")
app.include_router(templates_router, prefix="/api")

@app.get("/")
def root():
    return {"name": "LegalEase", "status": "running"}

@app.get("/health")
def health():
    return {"status": "healthy"}
