from pydantic import BaseModel, Field
from typing import Dict, Any

class DocumentCreate(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    document_type: str
    data: Dict[str, Any] = {}

class DocumentUpdate(BaseModel):
    content: str

class DocumentResponse(BaseModel):
    id: int
    title: str
    document_type: str
    status: str
    content: str

    class Config:
        from_attributes = True
